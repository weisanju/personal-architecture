OpenVPN 3 is distributed under
[GNU Affero General Public License version 3](LICENSES/AGPL-3.0-only.txt)
or [Mozilla Public License Version 2.0](LICENSES/MPL-2.0.txt).

with a special permission to link against OpenSSL when using AGPLv3:

    Additional permission under GNU AGPL version 3 section 7

    If you modify this Program, or any covered work, by linking or combining
    it with OpenSSL (or a modified version of that library), containing parts
    covered by the terms of the OpenSSL License or the Original SSLeay License,
    the licensors of this Program grant you additional permission to convey the
    resulting work. Corresponding Source for a non-source form of such a
    combination shall include the source code for the parts of OpenSSL used as
    well as that of the covered work.

Note that this special permission is only needed for OpenSSL versions
older than OpenSSL 3.0 as OpenSSL 3.0 uses the Apache 2.0 license
instead.
